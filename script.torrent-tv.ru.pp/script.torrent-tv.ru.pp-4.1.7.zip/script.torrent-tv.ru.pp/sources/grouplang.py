# -*- coding: utf-8 -*-

from __future__ import absolute_import, division, unicode_literals

translate = {
    'informational': "Новостные",
    'entertaining': "Развлекательные",
    'educational': "Познавательные",
    'movies': "Фильмы",
    'documentaries': "Документальные",
    'sport': "Спорт",
    'music': "Музыка",
    'regional': "Региональные",
    'religion': "Религиозные",
    'erotic_18_plus': "18+",
    'other_18_plus': "18+",
    'amateur': "18+",
    'эротика': "18+",
    'kids': "Детские",
    'series': "Сериалы",
}
