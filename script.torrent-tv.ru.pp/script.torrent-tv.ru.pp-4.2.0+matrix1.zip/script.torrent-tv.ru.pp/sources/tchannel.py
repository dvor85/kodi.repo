# -*- coding: utf-8 -*-
# Writer (c) 2017, Vorotilin D.V., E-mail: dvor85@mail.ru

from __future__ import absolute_import, division, unicode_literals

import datetime
import time
import os

from six.moves import UserDict
from six import itervalues
from utils import uni, fs_str

import defines
import logger
from epgs import epgtv
from epgs.epglist import Epg
import six
from .channel_info import CHANNEL_INFO
from .grouplang import translate


log = logger.Logger(__name__)


def sign(num):
    return "+" if num > 0 else "-"


class MChannel(UserDict):

    def __init__(self, chs=None):
        UserDict.__init__(self)
        if chs is None:
            chs = {}
        self.data.update(chs)

    def insert(self, index, ch):
        if self.title() != ch.title():
            for pu in self.xurl():
                for u in itervalues(pu[1]):
                    if ch['url']:
                        for cu in itervalues(ch['url']):
                            if isinstance(u[0], six.text_type) and isinstance(cu[0], six.text_type):
                                if u[0] == cu[0]:
                                    return
        if not isinstance(ch, self.__class__):
            while index in self.data:
                index += 1
            UserDict.__setitem__(self, index, ch)
        else:
            UserDict.update(ch)

    def group(self):
        for ch in itervalues(self.data):
            gr = ch.group()
            if gr:
                return gr

    def xurl(self):
        """
        [src_name, {player: (url, mode)}]
        """
        ret = []

        for ch in itervalues(self.data):
            if ch['url']:
                ret.append([ch.src(), ch['url']])
        return ret

    def logo(self):
        for ch in itervalues(self.data):
            lo = ch.logo()
            if lo:
                return lo

    def id(self):
        for ch in itervalues(self.data):
            _id = ch.id()
            if _id:
                return _id

    def name(self):
        for ch in itervalues(self.data):
            nm = ch.name()
            if nm:
                return nm

    def pin(self):
        for ch in itervalues(self.data):
            p = ch.get('pin')
            if p:
                return p

    def title(self):
        for ch in itervalues(self.data):
            tit = ch.title()
            if tit:
                return tit

    def epg(self):
        fep = None
        for ch in itervalues(self.data):
            ep = ch.epg()
#             Если нет описания, посмотреть в другом источнике
            if ep:
                fep = ep
                if 'event_id' in ep[0] or 'screens' in ep[0] or 'desc' in ep[0]:
                    return ep
        return fep


class TChannel(UserDict):

    def __init__(self, data=None, *args, **kwargs):
        UserDict.__init__(self, *args, **kwargs)
        if data is None:
            data = {}
        self.data.update(data)
        self.data.update(kwargs)
        self.logo_path = os.path.join(defines.CACHE_PATH, 'logo')
        if not os.path.exists(fs_str(self.logo_path)):
            os.mkdir(fs_str(self.logo_path))

    def src(self):
        return self.get('src', 'undefined')

    def player(self):
        return self.get('player', 'undefined')

    def __getitem__(self, key):
        if key == 'url':
            if not isinstance(self.data.get(key), dict):
                self.data[key] = {self.player(): (uni(self.data.get(key)), self.get('mode', 'PID'))}

        return UserDict.__getitem__(self, key)

#     def xurl(self):
#         if self.get('url') and not isinstance(self.get('url'), dict):
#             self.data['url'] = {
#                 self.player(): (uni(self.get('url')), self.get('mode'))
#             }
#         return self['url']

    def group(self):
        name = epgtv.get_name_offset(self.name().lower())[0]
        gr = uni(self.get('cat'))
        if name in CHANNEL_INFO:
            gr = CHANNEL_INFO[name].get('cat')
        # else:
        #     CHANNEL_INFO[name] = dict(cat=gr)
        if gr:
            self.data['cat'] = translate.get(gr.lower(), gr)
        return uni(self.get('cat'))

    def logo(self, session=None):
        logo = os.path.join(self.logo_path, "{name}.png".format(name=self.title().lower()))
        logo_url = None
        epg = None
        if os.path.exists(fs_str(logo)):
            self.data['logo'] = logo
            return logo
        if not self.get('logo'):
            epg = Epg().link
            if epg is not None:
                logo_url = epg.get_logo_by_name(self.name())
        elif '://' in self.get('logo'):
            logo_url = self.get('logo')

        try:
            if logo_url:
                _sess = epg.get_sess() if epg else session
                r = defines.request(logo_url, session=_sess)
                if len(r.content) > 0:
                    with open(fs_str(logo), 'wb') as fp:
                        fp.write(r.content)
                    self.data['logo'] = logo
        except Exception as e:
            log.e('update_logo error {0}'.format(e))

        return uni(self.get('logo'))

    def id(self):
        return uni(self.get('id', self.name()))

    def name(self):
        return uni(self.get('name'))

    def title(self):
        if not self.get('title'):
            name_offset = epgtv.get_name_offset(self.name().lower())
            ctime = datetime.datetime.now()
            offset = round((ctime - datetime.datetime.utcnow()).total_seconds() / 3600)
            if name_offset[0] in CHANNEL_INFO:
                self.data['title'] = CHANNEL_INFO[name_offset[0]].get('aliases', [name_offset[0]])[0].capitalize()
            else:
                self.data['title'] = name_offset[0].capitalize()
            if name_offset[1] and name_offset[1] != offset and sign(name_offset[1]):
                self.data['title'] += " ({sign}{offset})".format(sign=sign(name_offset[1]), offset=name_offset[1])
        return uni(self.data["title"])

    def update_epglist(self):
        try:
            epg = Epg().link
            if not self.get('epg') and epg is not None:
                self.data['epg'] = list(epg.get_epg_by_name(self.name()))
        except Exception as e:
            log.e('update_epglist error {0}'.format(e))

    def epg(self):
        """
        :return [{name, btime, etime},]
        """

        try:
            defines.MyThread(self.update_epglist).start().join(4)
            ctime = datetime.datetime.now()
            prev_x = {}
            curepg = []
            for x in self.get('epg', {}):
                try:
                    bt = datetime.datetime.fromtimestamp(float(x['btime']))
                    if prev_x and 'etime' not in prev_x:
                        prev_x['etime'] = x['btime']
                    if abs((bt - ctime).days) <= 1 and float(x['btime']) >= float(prev_x.get('etime', 0)) and \
                            (float(x.get('etime', 0)) >= time.time()):
                        curepg.append(x)
                    prev_x = x

                except Exception as e:
                    log.error(e)

            self.data['epg'] = curepg
        except Exception as e:
            log.e('epg error {0}'.format(e))

        return self.get('epg')


class TChannels:

    def __init__(self, name, reload_interval=-1, lock=None):
        self.name = name
        self.lock = lock
        self.channels = []
        self.reload_interval = reload_interval

    def update_channels(self):
        self.channels = []

    def get_channels(self):
        """
        :return [TChannel(),]
        """
        self.update_channels()
        return self.channels
