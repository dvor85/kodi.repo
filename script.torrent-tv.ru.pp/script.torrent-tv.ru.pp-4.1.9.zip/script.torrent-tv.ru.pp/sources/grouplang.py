# -*- coding: utf-8 -*-

from __future__ import absolute_import, division, unicode_literals

translate = {
    'informational': "Новостные",
    'news': "Новостные",
    'legislative': "Новостные",
    'business': "Деловые",
    'entertaining': "Развлекательные",
    'comedy': "Развлекательные",
    'entertainment': "Развлекательные",
    'educational': "Познавательные",
    'movies': "Фильмы",
    'кино': "Фильмы",
    'documentaries': "Документальные",
    'documentary': "Документальные",
    'travel': "Познавательные",
    'outdoor': "Познавательные",
    'sport': "Спорт",
    'sports': "Спорт",
    'music': "Музыка",
    'family': "Семейные",
    'regional': "Региональные",
    'local': "Региональные",
    'religion': "Религиозные",
    'religious': "Религиозные",
    'erotic_18_plus': "18+",
    'other_18_plus': "18+",
    'amateur': "18+",
    'эротика': "18+",
    'xxx': "18+",
    'kids': "Детские",
    'series': "Сериалы",
    'general': "Общие",
    'shop': "Магазины",

}
