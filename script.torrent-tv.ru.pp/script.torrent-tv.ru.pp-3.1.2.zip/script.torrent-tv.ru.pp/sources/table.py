# -*- coding: utf-8 -*-
# Writer (c) 2017, Vorotilin D.V., E-mail: dvor85@mail.ru


import ttv
import pomoyka
import allfon

Channels = dict(
    ttv=ttv.TTV(),
    pomoyka=pomoyka.Pomoyka(),
    allfon=allfon.Allfon(),
)
