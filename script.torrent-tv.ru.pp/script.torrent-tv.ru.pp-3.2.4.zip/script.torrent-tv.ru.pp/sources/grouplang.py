# -*- coding: utf-8 -*-

translate = {
    'informational': "Новостные",
    'entertaining': "Развлекательные",
    'educational': "Познавательные",
    'movies': "Фильмы",
    'documentaries': "Документальные",
    'sport': "Спорт",
    'music': "Музыка",
    'regional': "Региональные",
    'religion': "Религиозные",
    'erotic_18_plus': "Эротика",
    'other_18_plus': "Эротика",
    'amateur': "Эротика",
    'kids': "Детские",
    'series': "Сериалы",
}
